# 🚗 NotSoRichCarHunt — Reusable Agentic AI Workflow Package

> **A standardized, parameter-driven Agentic AI workflow for finding, auditing, and ranking executive & luxury used cars in the UK market without the financial traps.**

---

## 📦 What is Inside This Package?

This repository is configured as an official **Antigravity Custom Skill** (`not-so-rich-car-hunt`) and a complete **Microsoft Copilot Studio / Power Automate RPA** blueprint package.

```text
autotrader1/
├── .agents/
│   └── skills/
│       └── not-so-rich-car-hunt/
│           └── SKILL.md                 # Antigravity Skill Definition & Runbook
├── copilot_studio/
│   ├── README.md                        # Copilot Studio 8-Phase Deployment Roadmap
│   ├── 01_agent_configuration.md        # Persona, Entities, Variables, Adaptive Cards
│   ├── 02_cloud_flow_blueprint.md       # Power Automate Cloud Flow (Bing API + HTTP)
│   ├── 03_desktop_flow_rpa_blueprint.md # Power Automate Desktop (PAD) AutoTrader Scraper
│   └── 04_copilot_topic.yaml            # Importable Topic YAML for Copilot Studio
├── index.html                           # GDS-Styled HTML Report (Listing Rows)
├── index.css                            # Responsive GDS Stylesheet
├── hero.jpg                             # High-Resolution Automotive Hero Image
└── NOT_SO_RICH_CAR_HUNT.md              # This Master Reusable Package Guide
```

---

## 🚀 How Other Antigravity Users Can Reuse This Workflow

### 1. In Antigravity (Prompting & Conversational Re-use)

Any Antigravity agent in this workspace automatically discovers the skill in `.agents/skills/not-so-rich-car-hunt/SKILL.md`.

You or another user can simply invoke **`NotSoRichCarHunt`** in prompts like this:

#### Examples:
* **Add / Remove Brands:**
  > *"Hey NotSoRichCarHunt, add Toyota (RAV4 Hybrid) and Lexus (RX450h) into the SUV ranking, and remove Porsche."*
* **Change Budget & Postcode:**
  > *"NotSoRichCarHunt, re-run the hunt for budget £12,000 to £18,000 and postcode SW1A1AA."*
* **Filter by Body Type or Powertrain:**
  > *"NotSoRichCarHunt, show only plug-in hybrids (PHEVs) and petrol models across all brands."*
* **Regenerate the Web Report:**
  > *"NotSoRichCarHunt, re-render the index.html report with the updated cars and re-sort by reliability."*

---

## ⚙️ Parameters You Can Customize

| Parameter | Default | How to Override |
| :--- | :--- | :--- |
| **`POSTCODE`** | `IG50HY` | Tell the agent your outward+inward postcode (e.g. `B11AA`, `SW1A1AA`, `M11AE`). |
| **`BUDGET_MIN`** | `£10,000` | State your minimum budget (e.g. `£8,000`). |
| **`BUDGET_MAX`** | `£15,000` | State your ceiling budget (e.g. `£20,000`). |
| **`BRANDS`** | `BMW, Audi, Porsche, Jaguar, Land Rover, Mercedes-Benz` | Add/remove any brand (e.g., add Volvo, Toyota, Lexus, remove Porsche). |
| **`BODY_STYLES`** | `SUV, Saloon, Coupe` | Restrict to specific styles (e.g. SUVs only, or include Estates). |
| **`YEAR_MIN`** | `2015+` | Set minimum registration year. |
| **`EXCLUDE_WRITEOFFS`** | `true` | Enforces `&exclude-writeoff-categories=on` on all AutoTrader links. |

---

## 🛡️ Built-in Mechanical Audits & Defect Avoidance Rules

`NotSoRichCarHunt` automatically enforces safety rules so buyers don't get trapped with catastrophic repair bills:

1. **Jaguar F-Pace & Land Rover Discovery 5:** Strictly **2018+ ONLY** to avoid early Ingenium 2.0d timing chain guide failures and severe oil dilution.
2. **Mercedes-Benz GLE:** Strictly **Sep 2015+ (Euro 6)** with the durable OM651 diesel engine.
3. **Porsche Cayenne:** Recommends **2015–2017 (958.2 facelift)** with 3.6 V6 to avoid early Macan transfer case judders.
4. **BMW X5 (F15):** Late 2015+ N57 engine with audit notes for 80k-mile rear air suspension airbags.
5. **Audi Q7 / A7:** Enforces 40k-mile S-Tronic / Tiptronic gearbox fluid servicing history.
6. **Two-Phase Taxonomy & Stock Validation:** Ensures base `make` and `model` exist in AutoTrader's canonical dropdown list (e.g. `model=GLE`, `model=E%20Class`, `model=F-PACE`, `model=4%20Series%20Gran%20Coupe`) before layering radius, budget, and write-off exclusion filters.
7. **Statistical Maximum Mileage Capping:** Automatically computes optimal wear ceilings per vehicle class (e.g., $\le 60\text{k}$ for petrol city coupes/salons, $\le 70\text{k}$ for PHEV high-voltage battery warranty retention, $\le 80\text{k}$–$90\text{k}$ for robust V6 diesels) and injects `&maximum-mileage=X`.
8. **No CAT Markers:** All generated AutoTrader links enforce `&exclude-writeoff-categories=on`.

---

## 📊 Output Format (GOV.UK Design System)

The output is presented as an accessible, clean GDS **Row Listing** in [`index.html`](file:///d:/1/agentic/buyacar/autotrader1/index.html):
* **4-Column Layout:** Identity & Badges → Financial Metrics Table → AutoTrader Rating & Reliability Meter → Green GDS Search Button.
* **Dual-Key Sorting:** Ordered by **1) Reliability (High to Low)**, then **2) Insurance Cost (Lowest to Highest)**.
* **Sharing-Friendly:** Clean executive phrasing (*"Executive Comfort Seating, Generous Cabin Space & Refined Ergonomics"*).

---

## 🤖 Microsoft Copilot Studio & RPA Integration

To deploy this in Microsoft Power Platform / Copilot Studio:
1. Open [`copilot_studio/README.md`](./copilot_studio/README.md) for the complete 8-phase tutorial.
2. Import [`copilot_studio/04_copilot_topic.yaml`](./copilot_studio/04_copilot_topic.yaml) directly into your Copilot Studio topic canvas.
3. Hook up the Cloud Flow ([`02_cloud_flow_blueprint.md`](./copilot_studio/02_cloud_flow_blueprint.md)) or Desktop RPA Flow ([`03_desktop_flow_rpa_blueprint.md`](./copilot_studio/03_desktop_flow_rpa_blueprint.md)).
