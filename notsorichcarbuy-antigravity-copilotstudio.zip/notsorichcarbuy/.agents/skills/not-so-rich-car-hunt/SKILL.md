---
name: not-so-rich-car-hunt
description: >-
  Agentic AI workflow (NotSoRichCarHunt) for sourcing, auditing, and ranking executive, luxury, and reliable used cars in the UK market.
  Use when the user asks to search, filter, re-rank, add/remove brands, or generate GDS-styled HTML reports for used cars with customizable budget, postcode, and reliability constraints.
---

# NotSoRichCarHunt — UK Executive Used Car Sourcing Workflow

`NotSoRichCarHunt` is an end-to-end agentic workflow and market intelligence standard designed for Antigravity agents. It combs the UK used car market (AutoTrader, Parkers, HonestJohn) to identify, filter, rank, and present executive and family vehicles with high build quality, low maintenance risk, and sensible insurance costs.

---

## 1. Core Parameters & Defaults

When executing or modifying this workflow, extract or prompt for the following parameters:

| Parameter | Default Value | Description |
| :--- | :--- | :--- |
| `POSTCODE` | `IG50HY` | UK outward+inward postcode without space (e.g., `IG50HY`, `SW1A1AA`, `B11AA`). |
| `RADIUS` | `50` | Search radius in miles from `POSTCODE`. |
| `BUDGET_MIN` | `10000` | Minimum purchase price (£). |
| `BUDGET_MAX` | `15000` | Maximum purchase price (£). |
| `YEAR_MIN` | `2015` | Minimum manufacturing year. |
| `BRANDS` | `BMW, Audi, Porsche, Jaguar, Land Rover, Mercedes-Benz` | Target makes (customizable on demand). |
| `BODY_STYLES`| `SUV, Saloon, Coupe` | Approved body formats (wide-cabin & spacious seating priority). |
| `ULEZ_COMPLIANCE` | `true` | Must be Euro 6 Diesel or Euro 4+ Petrol/Hybrid (100% ULEZ exempt). |
| `EXCLUDE_WRITEOFFS` | `true` | Strictly append `&exclude-writeoff-categories=on` to AutoTrader search URLs. |
| `AESTHETICS` | `Dark Blue/Green Metallic, Black Alloys (19"+), Sunroof` | Visual styling criteria for best market finds. |
| `SORT_HIERARCHY` | `1) Reliability Index (High to Low), 2) Annual Insurance Cost (Low to High)` | Primary & secondary ordering keys. |

---

## 2. Dynamic Conversational Commands

When the user mentions `NotSoRichCarHunt`, interpret and apply dynamic modifications:

* **Brand Customization:**
  * *"NotSoRichCarHunt add Toyota, Lexus"* → Incorporate RAV4 / RX450h into the SUV evaluation; calculate reliability (typically 4.8/5) and insurance group.
  * *"NotSoRichCarHunt remove Porsche"* → Eliminate Cayenne/Macan rows and redistribute ranks.
* **Budget & Location Adjustment:**
  * *"NotSoRichCarHunt budget 12k-18k postcode B11AA"* → Update `BUDGET_MIN=12000`, `BUDGET_MAX=18000`, `POSTCODE=B11AA`, recalculate median mileages and update all AutoTrader URL parameters.
* **Body Style Toggle:**
  * *"NotSoRichCarHunt SUVs only"* or *"NotSoRichCarHunt include Estates"* → Rebuild report sections accordingly.

---

## 3. Defect Year Exclusions & Reliability Audit Rules

Before recommending any model year, enforce the following mandatory reliability rules:

| Brand / Model | Mandatory Year Rule | Known Failure Avoided |
| :--- | :--- | :--- |
| **Jaguar F-Pace** | **2018+ ONLY** | Early Ingenium 2.0d timing chain guide failures & software glitches. |
| **Land Rover Discovery 5** | **2018+ ONLY** | Early 2.0 SD4 timing chain stretch & oil dilution issues. |
| **Range Rover Evoque** | **2016+ (Euro 6) or Skip** | Euro 5 DPF non-compliance on early 2015 models. |
| **Mercedes-Benz GLE** | **Sep 2015+ ONLY** | Euro 5 vs Euro 6 facelift transition (W166 OM651 Euro 6 with AdBlue). |
| **Mercedes-Benz E-Class**| **2017+ ONLY** | W213 generation Euro 6 standard with OM654/OM651 engine. |
| **BMW X5 (F15)** | **Late 2015+ ONLY** | Pre-EU6 N57 compliance check. Inspect air suspension bags at ~80k mi. |
| **Porsche Cayenne** | **2015–2017 (958.2)** | Avoids early Macan transfer case shuddering & older pre-facelift Cayenne electronics. |
| **Audi Q7 / A7** | **2015+ (4M / C7)** | S-Tronic / Tiptronic 40,000-mile transmission fluid change mandatory. |

---

## 4. Two-Phase AutoTrader Taxonomy & Stock Verification Protocol

To prevent broken or zero-result search links, `NotSoRichCarHunt` mandates a **Two-Phase Verification Protocol** before emitting any recommendation:

### Phase 1: Base Make & Model Existence Validation (Taxonomy Check)
Before applying granular filters (postcode, radius, price-to, exclude-writeoffs), the agent validates that the `MAKE` and `MODEL` exist as canonical dropdown entries in AutoTrader's taxonomy by confirming base stock exists:
```text
https://www.autotrader.co.uk/car-search?make={MAKE}&model={CANONICAL_MODEL}&sort=relevance
```

#### Canonical AutoTrader Dropdown Taxonomy Reference:
| Brand | Target Model | Canonical `model=` Query Parameter | Note |
| :--- | :--- | :--- | :--- |
| **Mercedes-Benz** | GLE SUV | `model=GLE` | **NOT** `GLE-Class` or `GLE+Class` |
| **Mercedes-Benz** | E-Class Saloon | `model=E%20Class` | **NOT** `E-Class` or `E+Class` |
| **BMW** | 4 Series Gran Coupe | `model=4%20Series%20Gran%20Coupe` | Or `model=4%20Series` |
| **BMW** | 5 Series (PHEV/Saloon) | `model=5%20Series` | Direct canonical dropdown |
| **BMW** | X5 SUV | `model=X5` | Direct canonical dropdown |
| **Jaguar** | F-Pace SUV | `model=F-PACE` | Canonical uppercase `F-PACE` |
| **Jaguar** | XF Saloon | `model=XF` | Direct canonical dropdown |
| **Land Rover** | Discovery 5 | `model=Discovery` | Direct canonical dropdown |
| **Audi** | Q7 SUV | `model=Q7` | Direct canonical dropdown |
| **Audi** | A7 Sportback | `model=A7` | Direct canonical dropdown |
| **Porsche** | Cayenne SUV | `model=Cayenne` | Direct canonical dropdown |

### Phase 2: Progressive Constraint Layering
Once base model existence is confirmed, the agent layers the user's operational constraints:
```text
https://www.autotrader.co.uk/car-search?make={MAKE}&model={CANONICAL_MODEL}&postcode={POSTCODE}&radius={RADIUS}&price-to={BUDGET_MAX}&year-from={YEAR_MIN}&fuel-type={FUEL}&exclude-writeoff-categories=on&sort=relevance
```

### Phase 3: Zero-Result Fallback & Radius Relaxation
If strict local radius filtering (e.g. 50 miles) yields 0 results for a rarer luxury trim, the agent automatically notes the nationwide availability and provides the national search link (removing radius parameter) while keeping all safety and non-write-off filters intact.

## 5. Mathematical & Statistical Mileage Lifecycle Engine

Rather than applying arbitrary mileage caps, `NotSoRichCarHunt` calculates an **Optimal Maximum Mileage Ceiling (`maximum-mileage=M*`)** per vehicle class based on three quantitative horizons:

1. **UK Empirical Wear Rate:** Base age $T$ multiplied by UK median private mileage $\mu \approx 7,500\text{ miles/year}$.
2. **Major Component Half-Life ($L_{\text{half}}$):** The empirical boundary before high-cost preventative overhauls (air suspension airbags, turbochargers, S-Tronic mechatronics, NOx heating sensors).
3. **High-Voltage Battery Degradation Window (PHEVs):** The factory capacity retention warranty horizon (BMW 8-year / 100k-mile threshold $\implies$ target $\le 70,000\text{ miles}$ to guarantee $\ge 70\%$ usable EV capacity).

$$\text{Optimal Max Mileage } M^* = \min\left( L_{\text{major\_service\_horizon}}, \text{Median}_{\text{market}} + 0.5\sigma \right) \quad \text{[Binned to nearest 10,000]}$$

### Per-Vehicle Optimal Maximum Mileage Matrix:
| Vehicle Model | Powertrain / Class | Lifecycle Bottleneck | Optimal Cap (`maximum-mileage=`) |
| :--- | :--- | :--- | :--- |
| **Mercedes-Benz GLE 250d** | 2.1L OM651 Diesel | NOx sensors & Airmatic check | **`80000`** |
| **Audi Q7 3.0 TDI** | 3.0L V6 TDI | S-Tronic 2nd service / Airbag horizon | **`90000`** |
| **Porsche Cayenne 3.6 V6** | 3.6L V6 Petrol | Airmatic & Tiptronic risk horizon | **`80000`** |
| **Jaguar F-Pace 2.0d** | 2.0d Ingenium (2018+) | Revised chain guide preservation | **`70000`** |
| **BMW X5 xDrive30d** | 3.0L N57 Diesel | Rear air suspension degradation | **`80000`** |
| **Land Rover Discovery 5** | 2.0 SD4 Diesel (2018+) | Twin-turbo & compressor horizon | **`80000`** |
| **BMW 4 Series Gran Coupe** | 2.0L B48 Petrol | Low-wear city life (~30% engine wear) | **`60000`** |
| **Jaguar XF 2.0d** | 2.0d Ingenium (2018+) | Executive saloon low-wear window | **`60000`** |
| **Mercedes-Benz E220d** | 2.0L OM654 Diesel | Motorway lifecycle mid-point | **`80000`** |
| **Audi A7 3.0 TDI** | 3.0L V6 TDI Ultra | Dual-clutch mechatronic safety | **`80000`** |
| **BMW 530e M Sport (PHEV)**| 2.0L + 9.2kWh Battery | High-Voltage Battery health warranty | **`70000`** |

---

## 6. Report Generation Specifications (GDS Listing Rows)

When producing or updating the HTML report (`index.html` + `index.css`):

1. **Design System:** Strictly adhere to the **GOV.UK Design System (GDS)**:
   * Palette: Black (`#0b0c0c`), Brand Blue (`#1d70b8`), Success Green (`#00703c`), Error/Warning Red (`#d4351c`), Warning Yellow (`#f4c430`), Background (`#f8f9fa`).
   * Typography: Clean sans-serif / GDS Transport hierarchy (`govuk-heading-xl`, `govuk-heading-l`, `govuk-heading-m`, `govuk-body`).
2. **Layout Structure:**
   * **Full-Width Row Listings** (replacing card tiles) across 4 structured columns:
     * **Col 1 (Identity):** Rank Badge (`#1 Ranked SUV`), Make, Model, Fuel/Body tags, ULEZ pill, Non-writeoff pill.
     * **Col 2 (Financials):** Target Price, Median Mileage, Insurance Group, Estimated Insurance Premium, Road Tax (VED).
     * **Col 3 (Ratings & Audit):** AutoTrader score, visual reliability meter bar, recommended dark metallic/black alloy spec, critical mechanical watchouts.
     * **Col 4 (Action):** Green GDS search button linked directly to live filtered AutoTrader URL + guarantee badge.
3. **Sharing-Friendly Policy:**
   * Use neutral, executive phrasing: *"Executive Comfort Seating, Generous Cabin Space & Refined Ergonomics"*.
   * Do NOT include raw weight numbers (e.g., 90–120 kg) in user-facing subtitles.
4. **London Regulatory Notice:**
   * Always include the 2026 Congestion Charge notice (£18/day applies to private ICE/PHEV in Central London; 100% ULEZ free in Greater London).

---

## 7. Microsoft Copilot Studio & RPA Bridge

For Power Platform and Copilot Studio integrations:
* Reference [`copilot_studio/README.md`](../../copilot_studio/README.md) for the 8-phase deployment roadmap.
* Use [`01_agent_configuration.md`](../../copilot_studio/01_agent_configuration.md) for system prompts and custom entities.
* Use [`02_cloud_flow_blueprint.md`](../../copilot_studio/02_cloud_flow_blueprint.md) for standard Bing Search v7 API flows.
* Use [`03_desktop_flow_rpa_blueprint.md`](../../copilot_studio/03_desktop_flow_rpa_blueprint.md) for PAD Desktop UI scraping flows.
* Use [`04_copilot_topic.yaml`](../../copilot_studio/04_copilot_topic.yaml) for direct topic imports.
