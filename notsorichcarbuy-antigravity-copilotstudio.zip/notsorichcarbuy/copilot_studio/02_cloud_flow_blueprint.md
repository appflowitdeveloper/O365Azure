# Power Automate Cloud Flow Blueprint
## CarSourcing_CloudFlow_Search
### Approach: Standard Out-of-the-Box Connectors (HTTP + Bing + SharePoint)

---

## Overview

This Cloud Flow is called by the **Copilot Studio Action** (Plugin/Action node) and returns structured car listing data using Microsoft out-of-the-box connectors.  
No custom code or premium developer API keys are required.

```
Copilot Studio Action Node
        │
        ▼
[Cloud Flow: CarSourcing_CloudFlow_Search]
        │
        ├── Step 1: Parse inputs from Copilot
        ├── Step 2: Bing Web Search for AutoTrader listings
        ├── Step 3: HTTP GET to AutoTrader API (public, no auth)
        ├── Step 4: Filter results (CAT, ULEZ, Year, Mileage)
        ├── Step 5: Format output as JSON summary
        └── Step 6: Return formatted results to Copilot
```

---

## Step-by-Step Construction in Power Automate

### STEP 1 — Trigger: When Copilot Studio calls this flow

- **Trigger type:** `When a Copilot Studio action is called` (or: `When an HTTP request is received`)
- **Input Schema:** Add the following inputs in the trigger definition:

```json
{
  "type": "object",
  "properties": {
    "brand":       { "type": "string", "description": "Car brand (e.g. BMW, Audi)" },
    "bodyStyle":   { "type": "string", "description": "SUV or Saloon" },
    "maxBudget":   { "type": "integer", "description": "Maximum price in GBP" },
    "powertrain":  { "type": "string", "description": "Petrol, Diesel, PHEV, EV or Any" },
    "colour":      { "type": "string", "description": "Preferred colour" }
  },
  "required": ["brand", "maxBudget"]
}
```

---

### STEP 2 — Action: Initialize Variables

Add 4 **Initialize Variable** actions:

| Variable Name     | Type   | Value                           |
|-------------------|--------|---------------------------------|
| `varSearchQuery`  | String | (empty — set in next step)      |
| `varResultsJSON`  | String | (empty)                         |
| `varFilteredList` | Array  | `[]`                            |
| `varMinYear`      | Integer | `2015`                         |

---

### STEP 3 — Action: Compose Search Query

**Action type:** `Compose`  
**Inputs expression:**

```
concat(
  triggerBody()?['brand'], ' ',
  triggerBody()?['bodyStyle'], ' ',
  'used car UK under £',
  string(triggerBody()?['maxBudget']), ' ',
  triggerBody()?['powertrain'], ' ULEZ compliant ',
  triggerBody()?['colour'], ' metallic black alloys site:autotrader.co.uk'
)
```

Set `varSearchQuery` = output of Compose.

---

### STEP 4 — Action: Bing Web Search (Out-of-the-Box Connector)

- **Connector:** `Bing Search V7` (requires a free-tier Azure Bing Search resource)
- **Action:** `Web Search`
- **Settings:**

| Field           | Value                                      |
|-----------------|--------------------------------------------|
| Query           | `varSearchQuery`                           |
| Count           | `10`                                       |
| Market          | `en-GB`                                    |
| Safe Search     | `Off`                                      |

**Output:** `body/webPages/value` — an array of search result objects, each with `name`, `url`, `snippet`.

> **💡 Setup Tip:** Create a free Bing Search resource in Azure Portal → Marketplace → "Bing Search v7". Copy the key into the Power Automate connector when prompted.

---

### STEP 5 — Action: HTTP GET to AutoTrader (Public Search URL)

- **Action type:** `HTTP`
- **Method:** `GET`
- **URI:**

```
https://www.autotrader.co.uk/car-search?sort=relevance&postcode=IG50HY&radius=50&make=@{triggerBody()?['brand']}&bodyType=@{triggerBody()?['bodyStyle']}&price-to=@{triggerBody()?['maxBudget']}&fuel-type=@{triggerBody()?['powertrain']}&year-from=2015&colour=@{triggerBody()?['colour']}
```

- **Headers:**
```json
{
  "User-Agent": "Mozilla/5.0 (compatible; PowerAutomate)",
  "Accept":     "text/html,application/xhtml+xml"
}
```

> **Note:** AutoTrader does not have a public API. This HTTP step captures the raw HTML page. For structured extraction, use the **Desktop Flow** (Artifact 03) instead, which physically navigates and scrapes the site via UI Automation.

---

### STEP 6 — Action: Parse Bing Results + Build Summary

- **Action type:** `Apply to each`  
  Loop over `body/webPages/value` from Bing Search output (limit to 6 items).

Inside the loop:

```
[Condition]
  IF items('Apply_to_each')?['url'] contains 'autotrader.co.uk'
  AND items('Apply_to_each')?['snippet'] does NOT contain 'Cat N'
  AND items('Apply_to_each')?['snippet'] does NOT contain 'Cat S'
  THEN

  [Append to Array Variable: varFilteredList]
    Value (expression):
    {
      "title":   "@{items('Apply_to_each')?['name']}",
      "url":     "@{items('Apply_to_each')?['url']}",
      "summary": "@{items('Apply_to_each')?['snippet']}"
    }
```

---

### STEP 7 — Action: Apply Defect Year Filter

After the loop, add a **Filter Array** action:

- **From:** `varFilteredList`
- **Filter expression (Advanced):**

```
@and(
  not(contains(item()?['title'], '2016 Jaguar F-Pace')),
  not(contains(item()?['title'], '2017 Jaguar F-Pace')),
  not(contains(item()?['title'], '2017 Land Rover Discovery')),
  not(contains(item()?['summary'], 'Cat N')),
  not(contains(item()?['summary'], 'Cat S'))
)
```

---

### STEP 8 — Action: Format Output as Clean Text

- **Action type:** `Compose`
- **Expression:**

```
join(
  select(
    body('Filter_Array'),
    item(),
    concat(item()?['title'], ' → ', item()?['url'])
  ),
  '\n---\n'
)
```

---

### STEP 9 — Action: Respond to Copilot Studio

- **Action type:** `Return value(s) to Power Virtual Agents` (this is what Copilot Studio calls)  
- **Output definition:**

| Output Name     | Type   | Value                            |
|-----------------|--------|----------------------------------|
| `listingsResult`| String | Output of Step 8 Compose action  |
| `resultCount`   | Integer| `length(body('Filter_Array'))`   |

---

## Connector Licencing Summary

| Connector          | Licence Needed          | Notes                                 |
|--------------------|-------------------------|---------------------------------------|
| Bing Search V7     | Free Azure resource     | 1,000 free API calls/month            |
| HTTP               | Power Automate Standard | Included in M365 E3/E5 and standalone |
| Copilot Studio     | Copilot Studio licence  | Or included in M365 Copilot           |

---

## Error Handling — Add to Every Step

Right-click each action → **Configure run after** → enable `has failed` and `has timed out`.  
Add a **Scope** action wrapping Steps 4-8 and a **parallel branch** with:

```
[Send an email / Teams message]
  Subject: "CarSourcing Flow Failed"
  Body: "@{workflow()?['run']?['name']} failed at @{utcNow()}"
```
