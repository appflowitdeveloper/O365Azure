# Power Automate Desktop Flow Blueprint
## CarSourcing_Desktop_AutoTrader_Scrape
### Approach: RPA (UI Automation / Web Scraping via Power Automate Desktop)

---

## Overview

This Desktop Flow (PAD) is the **RPA fallback** — it physically opens a browser, navigates AutoTrader, applies all search filters, and extracts structured listing data by reading the webpage UI elements.

This is called from the **Cloud Flow** (Artifact 02) when the API/Bing approach returns insufficient results, or can be scheduled to run independently as a nightly scrape job.

```
Cloud Flow (Step 5 Fallback)
        │
        ▼
[PAD Desktop Flow: CarSourcing_Desktop_AutoTrader_Scrape]
        │
        ├── Module 1: Launch browser & navigate AutoTrader
        ├── Module 2: Apply search filters (Brand, Budget, Body, Fuel, Year, Colour)
        ├── Module 3: Scrape listing cards (loop all result pages)
        ├── Module 4: Filter out CAT markers, bad years, wrong colour
        ├── Module 5: Write results to SharePoint list / Excel
        └── Module 6: Return structured JSON to Cloud Flow
```

---

## Pre-Requisites on Your Machine

1. **Power Automate Desktop** (free — download from Microsoft)
2. **PAD machine registered** in Power Platform → Machines
3. **On-Premises Data Gateway** installed (required for Cloud Flow to trigger a Desktop Flow)
4. **Google Chrome** or **Microsoft Edge** (Chromium) installed
5. **Power Automate Browser Extension** installed in your chosen browser

---

## The Full Desktop Flow — Action by Action

> In PAD, create a new Desktop Flow called `CarSourcing_Desktop_AutoTrader_Scrape`.

---

### MODULE 1 — Input Variables (from Cloud Flow caller)

In PAD → **Input/Output Variables** tab, add:

| Variable   | Type   | Direction | Description                              |
|------------|--------|-----------|------------------------------------------|
| `Brand`    | Text   | Input     | e.g. "BMW" or "Audi"                     |
| `BodyType` | Text   | Input     | e.g. "SUV"                               |
| `MaxPrice` | Number | Input     | e.g. 15000                               |
| `FuelType` | Text   | Input     | e.g. "Petrol"                            |
| `Colour`   | Text   | Input     | e.g. "Blue"                              |
| `Results`  | Text   | Output    | JSON string of scraped listings          |
| `Status`   | Text   | Output    | "Success" or error message               |

---

### MODULE 2 — Launch Browser & Navigate AutoTrader

```
// Action: Launch new Microsoft Edge
Launch new Microsoft Edge
    Initial URL: 'https://www.autotrader.co.uk'
    Window state: Maximised
    → Store in: %Browser%

// Wait for page to load
Wait for web page to load
    Web browser instance: %Browser%

// Action: Navigate to search URL with embedded inputs
Navigate web browser to URL
    Web browser instance: %Browser%
    URL: $'https://www.autotrader.co.uk/car-search?sort=relevance&postcode=IG50HY&radius=50&make={Brand}&bodyType={BodyType}&price-to={MaxPrice}&fuel-type={FuelType}&year-from=2015&colour={Colour}'
    Wait for page to load: Yes
```

---

### MODULE 3 — Handle Cookie Banner

```
// Conditional: Accept cookies if banner present
If web page element exists
    Web browser instance: %Browser%
    UI Element: [AutoTrader cookie accept button — #onetrust-accept-btn-handler]
    → If Yes:
    
    Click link on web page
        Web browser instance: %Browser%
        UI Element: [AutoTrader cookie accept button]
```

---

### MODULE 4 — Extract Listing Count & Set Loop Limit

```
// Get total results count text (e.g. "1,243 cars found")
Extract data from web page
    Web browser instance: %Browser%
    UI Element: [.search-form__count] or [.results-title__count]
    → Store in: %TotalResultsText%

// Trim and convert to number
Set variable %TotalResultsText% to: Replace text(%TotalResultsText%, ',', '')
Set variable %TotalCount% to: ConvertTextToNumber(First word of %TotalResultsText%)

// Cap loop at 3 pages (≈30 listings max)
Set variable %MaxPages% to: 3
Set variable %CurrentPage% to: 1
Set variable %AllListings% to: []  // Empty list
```

---

### MODULE 5 — Main Scraping Loop (All Pages)

```
Loop
    Condition: %CurrentPage% <= %MaxPages%

    // Extract all listing cards on the current page
    Extract data from web page (Multiple values — List of elements)
        Web browser instance: %Browser%
        Data to extract:
            Column 1 "Title"    → CSS: article[data-standout-type] h3.listing-title
            Column 2 "Price"    → CSS: span.vehicle-price
            Column 3 "Mileage"  → CSS: li.atc-type-copy--medium:nth-child(1)
            Column 4 "Year"     → CSS: li.atc-type-copy--medium:nth-child(2)
            Column 5 "FuelType" → CSS: li.atc-type-copy--medium:nth-child(3)
            Column 6 "URL"      → Attribute: href from h3.listing-title > a
            Column 7 "Summary"  → CSS: p.listing-description__text
        Store results in: %PageListings%  (DataTable)

    // Append page results to AllListings
    For each %Listing% in %PageListings%
        Add item to list
            Item: %Listing%
            List: %AllListings%

    // Navigate to next page
    Increment variable %CurrentPage% by 1

    If %CurrentPage% <= %MaxPages%
        Click link on web page
            UI Element: [Next page button → a[data-gui='pagination-next']]
        Wait for web page to load
            Web browser instance: %Browser%

End Loop
```

---

### MODULE 6 — Filter Results (CAT, Year, Defect Years)

```
Set variable %FilteredListings% to: []

For each %Car% in %AllListings%

    // Extract year as integer
    Set %YearInt% to: ConvertTextToNumber(Left(%Car%['Year'], 4))

    // Build exclusion conditions
    Set %IsCatMarked% to:  Contains(%Car%['Summary'], 'Cat N') OR
                           Contains(%Car%['Summary'], 'Cat S') OR
                           Contains(%Car%['Summary'], 'Cat C') OR
                           Contains(%Car%['Summary'], 'Cat D') OR
                           Contains(%Car%['Title'], 'salvage')

    Set %IsBadYear%  to:  (%Car%['Title'] Contains 'Jaguar F-Pace' AND %YearInt% < 2018) OR
                          (%Car%['Title'] Contains 'Discovery 5'   AND %YearInt% < 2018) OR
                          (%Car%['Title'] Contains 'Macan'         AND %YearInt% < 2016)

    Set %IsBadPrice% to:  ConvertTextToNumber(Replace(%Car%['Price'], '£', '')) > %MaxPrice%

    If NOT %IsCatMarked% AND NOT %IsBadYear% AND NOT %IsBadPrice%
        Add item to list
            Item: %Car%
            List: %FilteredListings%

End For
```

---

### MODULE 7 — Convert Results to JSON & Return

```
// Convert DataTable / List to JSON manually using a text template
Set variable %JSONOutput% to: '['

For each %Car% in %FilteredListings%
    Set %JSONOutput% to: %JSONOutput% +
        '{' +
        '"title":"' + %Car%['Title'] + '",' +
        '"price":"' + %Car%['Price'] + '",' +
        '"mileage":"' + %Car%['Mileage'] + '",' +
        '"year":"' + %Car%['Year'] + '",' +
        '"url":"' + %Car%['URL'] + '",' +
        '"summary":"' + %Car%['Summary'] + '"' +
        '},'

End For

// Remove trailing comma and close array
Set %JSONOutput% to: TrimEnd(%JSONOutput%, ',') + ']'

// Set output variables
Set %Results% to: %JSONOutput%
Set %Status% to: 'Success'

// Close browser
Close web browser
    Web browser instance: %Browser%
```

---

### MODULE 8 — Error Handling (Wrap All Modules)

```
// In PAD: set "On block error" on the entire flow
On block error
    Set %Status% to: $'Error: {LastError.Message}'
    Set %Results% to: '[]'
    
    // Optional: Take screenshot for debugging
    Take screenshot
        Save to: 'C:\PAD_Logs\CarSourcing_Error_%CurrentDateTime%.png'
    
    Close web browser
        Web browser instance: %Browser%
```

---

## CSS Selectors Reference (AutoTrader UK — August 2026)

> ⚠️ AutoTrader periodically updates its HTML. Verify these selectors in browser DevTools (F12) before running.

| Element              | CSS Selector                                      |
|----------------------|---------------------------------------------------|
| Listing card wrapper | `article[data-standout-type]`                     |
| Car title            | `h3.listing-title a`                              |
| Price                | `span.vehicle-price`                              |
| Mileage              | `li[data-gui="mileage"]`                          |
| Year                 | `li[data-gui="year"]`                             |
| Fuel type            | `li[data-gui="fuel-type"]`                        |
| Listing URL          | `h3.listing-title a` → href attribute             |
| Description snippet  | `p.listing-description__text`                     |
| Next page button     | `a[data-gui="pagination-next"]`                   |
| Cookie accept        | `#onetrust-accept-btn-handler`                    |
| Results count        | `.search-form__count`                             |

---

## How to Register the Desktop Flow as a Cloud Flow Action

1. In **Power Automate (cloud)**, open `CarSourcing_CloudFlow_Search` (Artifact 02).
2. In Step 5 (fallback branch), add action: **Run a flow built with Power Automate Desktop**.
3. Select the machine your PAD is registered to.
4. Select flow: `CarSourcing_Desktop_AutoTrader_Scrape`.
5. Map inputs: `Brand` → `varBrand`, `MaxPrice` → `varMaxBudget` etc.
6. Map outputs: `Results` → `varListingsJSON` for return to Copilot.

---

## Scheduling the Desktop Flow (Optional — Nightly Scrape)

To run this automatically every night:

1. Create a new **Scheduled Cloud Flow** in Power Automate.
2. Set recurrence: Daily at **02:00 AM**.
3. Add action: **Run a flow built with Power Automate Desktop** → select your Desktop Flow.
4. Add action: **SharePoint → Create item** to save results to a SharePoint list for the Copilot to read from.
