# UK Executive Car Sourcing — Microsoft Copilot Studio Project
## README & Step-by-Step Setup Guide

---

## Project Overview

This project demonstrates a complete **Agentic AI workflow** built on Microsoft Copilot Studio and Power Automate. It automates the sourcing, filtering, and presentation of used executive cars in the UK market.

**Technologies used:**
- Microsoft Copilot Studio (Conversational AI / Agentic Actions)
- Power Automate Cloud Flows (HTTP / Bing Search connectors)
- Power Automate Desktop — PAD (RPA / UI Automation)

**Use case:** A conversational AI agent that asks users for their car preferences, then autonomously searches AutoTrader UK, filters out CAT markers and problematic vehicle years, and returns a curated shortlist.

---

## Artefact Inventory

| File | Description |
|------|-------------|
| [`01_agent_configuration.md`](./01_agent_configuration.md) | System prompt, entities, variables, trigger phrases, Adaptive Card |
| [`02_cloud_flow_blueprint.md`](./02_cloud_flow_blueprint.md) | Power Automate Cloud Flow using Bing + HTTP connectors |
| [`03_desktop_flow_rpa_blueprint.md`](./03_desktop_flow_rpa_blueprint.md) | Power Automate Desktop (RPA) — AutoTrader UI scraping |
| [`04_copilot_topic.yaml`](./04_copilot_topic.yaml) | Full Copilot Studio topic YAML (importable) |
| [`../index.html`](../index.html) | GDS-styled HTML output report (car search results) |

---

## Architecture Diagram

```
USER (Teams / Web / M365)
        │
        ▼
┌─────────────────────────────────────────┐
│         Microsoft Copilot Studio        │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │   Topic: UK Car Sourcing        │    │
│  │   ─────────────────────────     │    │
│  │   1. Ask: Brand                 │    │
│  │   2. Ask: Body Style            │    │
│  │   3. Ask: Powertrain            │    │
│  │   4. Ask: Colour                │    │
│  │   5. Call Action (Cloud Flow)   │    │
│  │   6. Fallback → Desktop Flow    │    │
│  │   7. Return Adaptive Card       │    │
│  └────────────┬────────────────────┘    │
└───────────────┼─────────────────────────┘
                │
        ┌───────┴──────────────────────────┐
        │                                  │
        ▼                                  ▼
┌──────────────────┐            ┌──────────────────────┐
│  CLOUD FLOW      │            │  DESKTOP FLOW (PAD)  │
│  (Primary)       │            │  (Fallback / Nightly)│
│                  │            │                      │
│  Bing Search V7  │            │  Opens Edge browser  │
│  HTTP GET        │            │  Navigates AutoTrader│
│  Filter Array    │            │  Scrapes UI elements │
│  Return JSON     │            │  Filters CAT/year    │
└──────────────────┘            │  Returns JSON        │
                                └──────────────────────┘
```

---

## Setup Instructions (Step by Step)

### PHASE 1 — Environment Prerequisites

- [ ] You have a **Microsoft 365** account (Business Basic or higher)
- [ ] You have a **Copilot Studio** licence (or M365 Copilot)
- [ ] You have a **Power Automate** licence (Standard or Premium)
- [ ] You have **Power Automate Desktop** installed on your Windows PC
- [ ] You have the **Power Automate browser extension** in Edge/Chrome

---

### PHASE 2 — Create the Copilot Studio Agent

1. Go to [https://copilotstudio.microsoft.com](https://copilotstudio.microsoft.com)
2. Click **Create** → **New copilot** → **Build it yourself**
3. Name: `UK Car Sourcing Agent`
4. Description: `Helps users find ULEZ-compliant executive used cars in the UK`
5. In **Settings → Generative AI → System prompt**: paste the system prompt from [`01_agent_configuration.md`](./01_agent_configuration.md)
6. Save the agent.

---

### PHASE 3 — Create Custom Entities

1. In Copilot Studio → **Settings → Entities → + New entity**
2. Create each entity as defined in Section 2 of [`01_agent_configuration.md`](./01_agent_configuration.md)
3. Save after creating each entity.

---

### PHASE 4 — Build the Cloud Flow (Primary Search)

1. In Power Automate → **My flows → + New flow → Automated cloud flow**
2. Name: `CarSourcing_CloudFlow_Search`
3. Trigger: **When a Copilot Studio action is called**
4. Follow all steps in [`02_cloud_flow_blueprint.md`](./02_cloud_flow_blueprint.md) step by step
5. **Setup Bing Search connector:**
   - Go to [portal.azure.com](https://portal.azure.com)
   - Search **Bing Search v7** in Marketplace → Create (Free tier)
   - Copy the API Key
   - In Power Automate: first time you add the Bing Search action, paste the key
6. Save and test the flow.

---

### PHASE 5 — Build the Desktop Flow (RPA Fallback)

1. Open **Power Automate Desktop** on your PC
2. Click **New flow** → Name: `CarSourcing_Desktop_AutoTrader_Scrape`
3. Add all **Input/Output Variables** as defined in Module 1 of [`03_desktop_flow_rpa_blueprint.md`](./03_desktop_flow_rpa_blueprint.md)
4. Build each module using the action-by-action pseudocode in the blueprint
5. Use **F5** to test the flow in PAD
6. **Register your machine:** In Power Automate cloud → **Machines → + New → Register** your PC
7. In `CarSourcing_CloudFlow_Search` (Phase 4): add the Desktop Flow call action in the fallback branch

---

### PHASE 6 — Import the Topic into Copilot Studio

1. In Copilot Studio → **Topics → + Add topic → From blank**
2. Click `</>` (YAML view) in the top right
3. Delete all existing content
4. Paste the entire YAML from [`04_copilot_topic.yaml`](./04_copilot_topic.yaml)
5. Click **Save**
6. Connect the `InvokeFlowAction` nodes to your actual flow names (Step 4 & 5 above)

---

### PHASE 7 — Test End to End

1. In Copilot Studio, click **Test** (chat panel on the right)
2. Type: `Find me a roomy BMW SUV under £15k`
3. Walk through all 4 questions
4. Verify the Adaptive Card is returned with listings
5. Verify the AutoTrader button opens the correct filtered URL

---

### PHASE 8 — Publish (Optional)

1. In Copilot Studio → **Publish → Publish to Microsoft Teams**
2. Or: **Publish → Demo website** (for sharing a link)
3. Or: Embed the agent in a website using the provided script snippet

---

## Common Troubleshooting

| Issue | Fix |
|-------|-----|
| Desktop Flow doesn't trigger from Cloud | Ensure On-Premises Data Gateway is installed and machine is registered |
| Bing returns no results | Check API key is valid; verify Azure Bing Search resource is active |
| YAML import fails | Ensure no trailing spaces after YAML lines; use a YAML validator first |
| AutoTrader CSS selectors broken | AutoTrader updates HTML periodically. Re-inspect with F12 DevTools |
| Copilot Topic doesn't recognise entities | Ensure entity names match exactly as referenced in YAML variables |

---

## Career Pivot Notes

This project demonstrates the following skills to potential employers:

| Skill | Where Demonstrated |
|-------|--------------------|
| **Conversational AI Design** | Copilot Studio agent config, topic YAML |
| **RPA / Desktop Automation** | PAD Desktop Flow with UI element scraping |
| **API Integration** | Cloud Flow with Bing Search + HTTP connectors |
| **Power Automate Cloud Flows** | Flow design, error handling, data transformation |
| **Data Filtering & Governance** | CAT filter, defect year exclusions, ULEZ compliance |
| **Adaptive Cards** | Output card design in Copilot Studio |
| **End-to-End Agentic Design** | Full loop from NLU intent → action → result display |
