# Copilot Studio — Agent Configuration
## UK Executive Car Sourcing Agent

---

## 1. Agent Identity & System Prompt

In Copilot Studio → **Settings → Generative AI → System Prompt**, paste this:

```
You are a UK Executive Car Market Expert and RPA Architect.

Your role is to help users find the best used executive/luxury SUV or large saloon from ONLY these brands: BMW, Audi, Porsche, Jaguar, Land Rover, Mercedes-Benz.

Rules you MUST always follow:
- Budget: £10,000 to £15,000 only. Never suggest cars outside this range unless asked.
- ULEZ compliance is mandatory. Only suggest Euro 6 Diesel or Euro 4+ Petrol/Hybrid vehicles.
- Exclude any vehicle with a CAT-N, CAT-S, CAT-C or CAT-D marker.
- Exclude vehicles from problematic manufacturing years (e.g., Jaguar/Land Rover Ingenium diesels pre-2018).
- Prioritise wide, non-bolstered comfort seats (14-way adjustable minimum) suitable for passengers 90-120kg.
- Preferred colours: Blue Metallic, Green Metallic, or any distinctive Metallic finish.
- Preferred wheels: Black alloy wheels, 19 inch or larger.
- Only recommend 2015 or newer vehicles.
- Always provide: estimated annual VED, Insurance Group, median mileage for the budget, and top 3 known reliability concerns.
- Never invent listings. Only confirm as "available" if data has been retrieved via your connected Power Automate Action.
```

---

## 2. Language Understanding — Custom Entities

Create these custom entities in Copilot Studio → **Entities**:

| Entity Name         | Type           | Values / Pattern                                                            |
|---------------------|----------------|-----------------------------------------------------------------------------|
| `BodyStyle`         | Closed list    | SUV, Saloon, Coupe, Estate                                                  |
| `BrandPreference`   | Closed list    | BMW, Audi, Porsche, Jaguar, Land Rover, Mercedes-Benz, Any                  |
| `PowertrainType`    | Closed list    | Petrol, Diesel, PHEV, EV, Any                                               |
| `MaxBudget`         | Prebuilt: Money | Pattern: £[amount] or "under £[amount]"                                    |
| `PassengerBuild`    | Closed list    | Standard, Larger Build (90-120kg), Larger Build (120-140kg)                |
| `ColourPreference`  | Closed list    | Blue, Green, Grey, Black, White, Any Metallic                               |
| `MaxMileage`        | Prebuilt: Number | Pattern: "[number]k miles" or "under [number],000 miles"                  |

---

## 3. Conversational Variables

Create these in each Topic (scoped to **Topic**):

| Variable Name            | Type    | Source              | Purpose                                               |
|--------------------------|---------|---------------------|-------------------------------------------------------|
| `varBrand`               | String  | Entity: BrandPreference | Which brand(s) to search                         |
| `varBodyStyle`           | String  | Entity: BodyStyle   | SUV or Saloon etc.                                    |
| `varMaxBudget`           | Number  | Entity: MaxBudget   | Max price in GBP (default: 15000)                     |
| `varPowertrain`          | String  | Entity: PowertrainType | Engine preference                                 |
| `varPassengerBuild`      | String  | Entity: PassengerBuild | For seat width filtering                          |
| `varColour`              | String  | Entity: ColourPreference | Colour preference                               |
| `varMaxMileage`          | Number  | User input / default | Max mileage (default: 60000)                        |
| `varListingsJSON`        | String  | Action output       | Raw JSON returned from Power Automate Cloud Flow      |
| `varDesktopFlowStatus`   | String  | Action output       | Status from PAD Desktop Flow scrape                   |

---

## 4. Topic Trigger Phrases

In Copilot Studio → **Topics → New Topic → Triggers**, add these phrases:

```
Find me a car
Search for executive cars
Show me luxury SUVs under £15k
I need a ULEZ compliant car
Find me a roomy BMW or Audi
What's available in my budget
Search AutoTrader for me
Car sourcing
Start car search
What cars should I buy
```

---

## 5. Topic Flow — Node-by-Node Design

```
[TRIGGER] → User says one of the trigger phrases above

[MESSAGE NODE] 
  "Great! I'm your Executive Car Sourcing Agent. Let me ask a few quick questions."

[QUESTION NODE 1] → stores: varBrand
  "Which brand do you prefer? (BMW, Audi, Porsche, Jaguar, Land Rover, Mercedes, or Any)"
  Entity: BrandPreference

[QUESTION NODE 2] → stores: varBodyStyle  
  "Body style: SUV or Saloon?"
  Entity: BodyStyle

[QUESTION NODE 3] → stores: varPowertrain
  "Powertrain preference: Petrol, Diesel, PHEV, EV, or Any?"
  Entity: PowertrainType

[QUESTION NODE 4] → stores: varColour
  "Colour preference: Blue, Green, Grey, or Any Metallic?"
  Entity: ColourPreference

[CONDITION NODE]
  IF varBrand = "Any" THEN varBrand = "BMW,Audi,Porsche,Jaguar,Land Rover,Mercedes"

[MESSAGE NODE]
  "Perfect. Let me search the market for you now. This may take a moment..."

[ACTION NODE 1] → Call Power Automate Cloud Flow: "CarSourcing_CloudFlow_Search"
  Inputs:  varBrand, varBodyStyle, varMaxBudget (15000), varPowertrain, varColour
  Output → varListingsJSON

[CONDITION NODE]
  IF varListingsJSON = "" OR "error" THEN

    [ACTION NODE 2] → Call PAD Desktop Flow: "CarSourcing_Desktop_AutoTrader_Scrape"
    Inputs:  varBrand, varBodyStyle, varMaxBudget, varPowertrain, varColour
    Output → varListingsJSON

[MESSAGE NODE — Adaptive Card]
  Display results from varListingsJSON using Adaptive Card (see section 6)

[QUESTION NODE — Optional]
  "Would you like to refine the search? (Yes / No)"
  IF Yes → Loop back to QUESTION NODE 1
  IF No → End topic with summary message
```

---

## 6. Adaptive Card Output Template

Paste into Copilot Studio Adaptive Card editor when building your Message Node:

```json
{
  "type": "AdaptiveCard",
  "version": "1.4",
  "body": [
    {
      "type": "TextBlock",
      "text": "Car Sourcing Results",
      "weight": "Bolder",
      "size": "Large"
    },
    {
      "type": "TextBlock",
      "text": "Top matches found within £10,000 - £15,000:",
      "wrap": true
    },
    {
      "type": "FactSet",
      "facts": [
        { "title": "Brand", "value": "${varBrand}" },
        { "title": "Body Style", "value": "${varBodyStyle}" },
        { "title": "Budget", "value": "Up to £${varMaxBudget}" },
        { "title": "Powertrain", "value": "${varPowertrain}" }
      ]
    },
    {
      "type": "TextBlock",
      "text": "${varListingsJSON}",
      "wrap": true,
      "color": "Good"
    }
  ],
  "actions": [
    {
      "type": "Action.OpenUrl",
      "title": "Search AutoTrader",
      "url": "https://www.autotrader.co.uk/car-search?sort=relevance&postcode=IG50HY&radius=50"
    }
  ]
}
```

---

## 7. Known Defect Year Filter — Reference Table

Add this as a knowledge source in Copilot Studio (upload as a CSV) and reference in your Power Automate flows:

| Brand       | Model           | Avoid Years     | Reason                                        |
|-------------|-----------------|-----------------|-----------------------------------------------|
| Jaguar      | F-Pace          | 2016–2017       | Ingenium timing chain guide failure            |
| Land Rover  | Discovery 5     | 2017            | Early Ingenium software & chain faults         |
| Land Rover  | Evoque          | 2012–2015       | Pre-Ingenium engine & old-gen reliability      |
| Porsche     | Macan           | 2014–2015       | Transfer case judder on early units            |
| BMW         | X5 (F15)        | Pre-late 2015   | Must be late 2015+ for Euro 6 compliance       |
| Mercedes    | GLE (W166)      | Pre-Sep 2015    | Euro 5 only before September 2015 facelift     |
| Audi        | Q7 (4M)         | N/A             | Clean from 2015 launch — no major year issues  |
