﻿// See https://aka.ms/new-console-template for more information
using System.Globalization;
using System.Text.RegularExpressions;

try
{
    Console.ForegroundColor = ConsoleColor.DarkYellow;
    Console.WriteLine(Environment.NewLine + "Please ensure this program has write permissions on the folder/files. Or RunAs Administrator if in doubt.");
    Console.WriteLine(Environment.NewLine + "This console app -> begins sorting+renaming barclays bank statement files (*.pdf) in the current folder in chronological order of Accounts & 'dd-MMM-yy' ");
    Console.ForegroundColor = ConsoleColor.DarkRed;
    Console.WriteLine(Environment.NewLine + "Press  y|Y ....  ");

    ConsoleKeyInfo consoleKeyInfo = Console.ReadKey();
    if (consoleKeyInfo.KeyChar != 'y' && consoleKeyInfo.KeyChar != 'Y')
    {
        return;
    }

    var list = (from file in Directory.GetFiles(Directory.GetCurrentDirectory(), "*.pdf")
                let fileinfo = new FileInfo(file)

                let dt = new Regex("\\d\\d-(\\w){3}-(\\d){2}").Match(fileinfo.Name)

                let accno = new Regex("ac\\s(\\d){8}").Match(fileinfo.Name)

                where !string.IsNullOrEmpty(dt.Value)

                select new
                {
                    File = fileinfo,
                    DateText = dt.Value,
                    DateValue = DateTime.Parse(dt.Value),
                    AccountNumber = accno.Value.Trim()

                });

    if (list.Any())
    {
        int num = 1;
        string text = "";
        {
           var oList = (from one in list
                    orderby one.AccountNumber, one.DateValue
                    select one).ToList();

            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine(Environment.NewLine + $"{oList.Count} files found with dd-mmm-yy format in filename." + Environment.NewLine);

            foreach (var item in oList)
            {
                num = ((!text.Equals(item.AccountNumber)) ? 1 : (num + 1));

                string text2 = $"{item.AccountNumber.Replace("ac ", "")} -- {num.ToString("0000")} -- {item.DateValue.Year} {item.DateValue.ToString("MMMM").PadLeft(13, ' ')}" + $" -- { new Regex("statement.*").Match(item.File.Name.ToLower()).Value}".PadLeft(40,' ');

                string text3 = Path.Join(item.File.DirectoryName, text2);

                if (!File.Exists(text3))
                {
                    File.Move(item.File.FullName, text3);
                    Console.WriteLine("Renamed: " + item.File.Name + " |to| " + text2);
                }
                else
                {
                    Console.WriteLine("Skipped (file/name already/exists): " + item.File.Name);
                }
                text = item.AccountNumber;
            }
            return;
        }
    }
    Console.ForegroundColor = ConsoleColor.DarkCyan;
    Console.WriteLine(Environment.NewLine + "0 files found - with dd-mmm-yy format in filename - 0 files processed.");
}
catch (Exception ex)
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine(Environment.NewLine + ex.ToString() + Environment.NewLine);
    File.AppendAllText("cliSortRenameFilesByDateText_ddmmyy.log.txt", ex.ToString() + Environment.NewLine + ex.StackTrace);
}
finally
{
    Console.ReadKey();
}
