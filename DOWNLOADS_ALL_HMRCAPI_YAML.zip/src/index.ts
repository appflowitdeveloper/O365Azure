import puppeteer from 'puppeteer';
import fs from 'fs-extra';
import path from 'path';

const BASE_URL = 'https://developer.service.hmrc.gov.uk/api-documentation/docs/api?searchTerm=&docTypeFilters=API&docTypeFilters=TEST_SUPPORT_API';
const OUTPUT_DIR = path.join(__dirname, '../output');
const DOWNLOAD_DIR = path.join(OUTPUT_DIR, 'downloads'); // <-- FIXED: removed leading slash
const HTML_FILE = path.join(OUTPUT_DIR, 'developer_service_hmrcgovuk__apidocumentation_docs_api.html');

console.log(`OUTPUT_DIR: ${OUTPUT_DIR}`);
console.log(`DOWNLOAD_DIR: ${DOWNLOAD_DIR}`);

interface ApiEntry {
  row: number;
  heading: string;
  description: string;
  links: {
    url: string;
    currentVersion?: string;
    currentVersionUrl?: string;
    downloadFilePath?: string;
    downloadFileName?: string;
  }[];
}

async function scrape() {
  await fs.ensureDir(DOWNLOAD_DIR);
  await fs.ensureDir(OUTPUT_DIR);
  const browser = await puppeteer.launch();
  const page = await browser.newPage();

  console.log('');
  console.log(`Navigating to BASE_URL: ${BASE_URL}`);
  console.log('');

  await page.goto(BASE_URL, { waitUntil: 'networkidle2' });

  const apiEntries: ApiEntry[] = await page.$$eval('li.govuk-apis-list-item', (items) => {
    return items.map((li) => {
      const heading = (li.querySelector('h2.govuk-heading-m') as HTMLElement)?.innerText.trim() || '';
      const description = (li.querySelector('p.govuk-body') as HTMLElement)?.innerText.trim() || '';
      const links = Array.from(li.querySelectorAll('a.govuk-link--no-underline.govuk-link--no-visited-state')).map((a) => ({
        url: (a as HTMLAnchorElement).href
      }));
      return { row: 0, heading, description, links };
    });
  });

  // Assign row numbers here
  apiEntries.forEach((entry, idx) => {
    entry.row = idx + 1;
  });

  for (const entry of apiEntries) {
    for (const link of entry.links) {
      console.log(`Navigating to API detail page: ${link.url}`);
      await page.goto(link.url, { waitUntil: 'networkidle2' });
      // Get currentVersion and its URL
      try {
        const { versionText, versionUrl } = await page.$eval('td#currentVersion', (td) => {
          const a = td.querySelector('a[href]');
          return {
            versionText: td.textContent?.trim() || '',
            versionUrl: a ? (a as HTMLAnchorElement).href : ''
          };
        });
        link.currentVersion = versionText;
        link.currentVersionUrl = versionUrl;
      } catch {
        link.currentVersion = '';
        link.currentVersionUrl = '';
      }

      // If there is a currentVersionUrl, navigate to it before looking for the download link
      if (link.currentVersionUrl) {
        console.log(`*==>Navigating to currentVersionUrl: ${link.currentVersionUrl}`);
        await page.goto(link.currentVersionUrl, { waitUntil: 'networkidle2' });
      }

      // Set download behavior for Puppeteer
      const client = await page.target().createCDPSession();
      await client.send('Page.setDownloadBehavior', {
        behavior: 'allow',
        downloadPath: DOWNLOAD_DIR,
      });

      // Try to click the download link
      try {
        const downloadHandle = await page.$('a[download]');
        if (downloadHandle) {
          await downloadHandle.click();

          // Wait for the file to appear in the download directory
          const fileName = entry.heading + '.yaml';
          let downloadedFile = '';
          for (let i = 0; i < 20; i++) { // Wait up to ~10 seconds
            const files = await fs.readdir(DOWNLOAD_DIR);
            const found = files.find(f => f.includes('application.yaml'));
            if (found) {
              downloadedFile = found;
              const oldPath = path.join(DOWNLOAD_DIR, downloadedFile);
              const newPath = path.join(DOWNLOAD_DIR, fileName);

              // Rename the file to entry.heading+'.yaml'
              try {
                await fs.rename(oldPath, newPath);
                downloadedFile = fileName;
              } catch (renameErr) {
                console.log(`Error renaming file ${oldPath} to ${newPath}:`, renameErr);
              }

              break;
            }
            await new Promise(res => setTimeout(res, 500));
          }
          if (downloadedFile) {
            link.downloadFilePath = path.join(DOWNLOAD_DIR, downloadedFile);
            link.downloadFileName = downloadedFile;
            console.log(`!==> FOUND: "${downloadedFile}"`);
          } else {
            link.downloadFilePath = undefined;
            link.downloadFileName = undefined;
            console.log('=> NOT FOUND: ' + fileName);
          }
        } else {
          link.downloadFilePath = undefined;
          link.downloadFileName = undefined;
          console.log('No download link found on this page.');
        }
      } catch (err) {
        console.log('Error during download:', err);
        link.downloadFilePath = undefined;
        link.downloadFileName = undefined;
      }
    }
  }
  await browser.close();
  return apiEntries;
}

function buildHtml(apiEntries: ApiEntry[]) {
  let html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>HMRC DEV-HUB-API List</title></head><body>`;
    html += `<table border="1" cellpadding="5" cellspacing="0"><thead><tr><th>#</th><th>Current Version</th><th>Heading</th><th>Description</th><th>Download</th></tr></thead><tbody>`;
  for (const entry of apiEntries) {
    for (const link of entry.links) {
      html += `<tr>`;
      html += `<td>${entry.row}</td>`;
      html += `<td><a href="${link.currentVersionUrl || ''}">${link.currentVersion || 'N/A'}</a></td>`;
      html += `<td>${entry.heading}</td>`;
      html += `<td>${entry.description}</td>`;      
      if (link.downloadFileName) {
        html += `<td><a href="./downloads/${link.downloadFileName}" download>${link.downloadFileName}</a></td>`;
      } else {
          html += `<td>N/A: not_a_.yaml</td>`;
      }
      html += `</tr>`;
    }
  }
  html += `</tbody></table></body></html>`;
  return html;
}

async function main() {
  const apiEntries = await scrape();
  const html = buildHtml(apiEntries);
  await fs.writeFile(HTML_FILE, html);
  console.log('Done!');
  console.log(`BEFORE RE-RUNNING! THIS RPA/SCRAPPER/PROCESS: ENSURE: ALL FILES ARE REMOVED FROM FOLDER : ${DOWNLOAD_DIR}`);
}
main().catch(console.error);