﻿

$siteUrl = "https://appflowitjan2019.sharepoint.com/sites/sal"

Connect-PnPOnline -Url $siteUrl -Credentials (Get-Credential)

##Get-PnPProvisioningTemplate -Out ("{0}\{1}.xml"-f 'D:\Code\SAL\pnpprovision', "site_sal_pnptemplate") -IncludeAllTermGroups

Apply-PnPProvisioningTemplate -Path ("{0}\{1}.xml"-f 'D:\Code\SAL\pnpprovision', "site_sal_pnptemplate") -ClearNavigation


Read-Host -Prompt "Press Enter to exit"
